﻿global using System.Net.Mime;
global using System.Text.Json;
global using FluentAssertions;
global using GamingApi.Tests.SharedKernel.Attributes;
global using NSubstitute;
global using RichardSzalay.MockHttp;
global using Xunit;
