﻿global using System.Net;
global using System.Text.Json;
global using System.Text.Json.Serialization;
global using System.Text.RegularExpressions;
global using FluentValidation;
global using MediatR;
global using Riok.Mapperly.Abstractions;
