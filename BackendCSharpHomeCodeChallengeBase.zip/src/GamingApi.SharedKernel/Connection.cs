﻿namespace GamingApi.Games;

public sealed record Connection(string Name, string BaseUrl, string Path);
