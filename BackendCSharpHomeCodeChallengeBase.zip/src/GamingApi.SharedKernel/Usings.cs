﻿global using System.Net;
global using System.Reflection;
global using FluentValidation;
global using MediatR;
global using Microsoft.Extensions.DependencyInjection;
